
# 🛠️ ROS Mapping & Navigation Project

This ROS1 project is divided into two main phases: **Mapping** and **Navigation**, using a dataset provided in the form of a ROS Bag. The robot is equipped with front and back laser scanners and provides noisy odometry data. The final result is a robot capable of mapping an unknown environment and navigating through it autonomously using a goal list.

---

## 📦 Dataset Description

The data used for both phases is provided as a ROS Bag file.

### ▶️ Playing the Bag
```bash
rosbag play --clock robotics2.bag
```

### 📁 Available Topics
- `/odometry`: Noisy odometry data  
- `/scan_front`: Laser scan from front sensor  
- `/scan_back`: Laser scan from rear sensor  
- `/tf`: Dynamic transform tree  
- `/tf_static`: Static transforms (e.g., sensor mounting positions)

---

## 🚧 Task 1: Mapping

In the first phase, we generate a 2D occupancy grid map using the [GMapping](http://wiki.ros.org/gmapping) SLAM algorithm.

### 🧩 Main Steps
- Convert `/odometry` to a `tf` transform  
- Merge `/scan_front` and `/scan_back` to get full 360° laser coverage  
- Filter out robot body parts from the scans using the [`ira_laser_tools`](http://wiki.ros.org/ira_laser_tools) package  
- Visualize map and sensors using RViz  
- Configure the global frame to `map`

### 🚀 Launch File
The `gmapping.launch` file:
- Starts GMapping and required preprocessing nodes
- Creates the back static TF, not provided in the bag file  
- Uses `ira_laser_merger` to merge laser scans  
- Includes robot body point filtering  
- Launches RViz with a custom config to display the map, TF, and LIDAR

### 🗺️ Result
A complete map of the environment suitable for navigation.

![Map Obtained](img/map_precise.png)

---

## 🤖 Task 2: Navigation

In the second phase, we simulate the robot and use the [Navigation Stack](http://wiki.ros.org/navigation) to reach a series of goals in the generated map.

### 🛠️ Simulation Setup
- Simulation with **Stage** using a robot sized **0.54m x 0.40m**  
- **Robot kinematics: Omnidirectional**  
- Localization: `amcl` (Adaptive Monte Carlo Localization)  
- Path planning: `dwa_local_planner` (Dynamic Window Approach)

### 🎯 Goal Publisher
A custom node `goal_pub`:
- Reads waypoints from `second_project/csv/goals.csv`  
- Publishes a new goal only when the previous one is reached or aborted

### 🚀 Launch File
The `navigation.launch` file:
- Starts `move_base`, `amcl`, and the simulated robot  
- Runs `goal_pub` to send goals from the CSV

![Obtained Localization](img/running.png)

---

## 📌 Dependencies

- `gmapping`  
- `ira_laser_tools`  
- `amcl`  
- `move_base`  
- `stage_ros`  
- `dwa_local_planner`  
- `tf`, `tf_static`  
- `rosbag`, `roscpp`, `sensor_msgs`, `nav_msgs`, `geometry_msgs`

## 👨‍💻 Authors

This project was developed by **Francesco Lazzaro**,  **Juan David Lopez Molano** and **Andres Felipe Forero Salas** as part of an academic and practical exploration of vehicle localization using ROS.

---

For further customization, dataset substitution, or circuit changes, feel free to fork and adapt this project.
