#include <ros/ros.h>
#include <nav_msgs/Odometry.h>
#include <tf/transform_broadcaster.h>

class Odom_TF{
    private:
        // ROS node handle
        ros::NodeHandle nh;

        // Publisher and Subscriber
        ros::Publisher odom_pub;
        ros::Subscriber odom_sub;

        // ROS TF Broadcaster
        tf::TransformBroadcaster br;
        tf::Transform transform; // Transform object (message)
        tf::Quaternion q; // Quaternion object (message)

    public:

        //Constructor
        Odom_TF(){
            odom_sub = nh.subscribe("/odometry", 1000, &Odom_TF::tfPubCallback, this);
        }

        void tfPubCallback(const nav_msgs::Odometry::ConstPtr& msg){
            // Create a transform object
            transform.setOrigin(tf::Vector3( // Set the position
                                            msg->pose.pose.position.x, 
                                            msg->pose.pose.position.y, 
                                            msg->pose.pose.position.z
            )); 

            // Set the orientation based on the quaternion available in the odometry message
            q.setX(msg->pose.pose.orientation.x);
            q.setY(msg->pose.pose.orientation.y);
            q.setZ(msg->pose.pose.orientation.z);
            q.setW(msg->pose.pose.orientation.w);
            transform.setRotation(q);

            //Publish the updated transform
            br.sendTransform(tf::StampedTransform(transform, ros::Time::now(), "odom", "base_link"));
        }
};

int main(int argc, char **argv)
{
    // Initialize the ROS node
    ros::init(argc, argv, "odom_to_TF");

    // Create an instance of the Odometer class
    Odom_TF odom_TF;

    // Spin to keep the node running
    ros::spin();

    return 0;
}