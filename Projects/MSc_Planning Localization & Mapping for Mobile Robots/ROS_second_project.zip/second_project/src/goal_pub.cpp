#include <ros/ros.h>
#include <actionlib/client/simple_action_client.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <geometry_msgs/Quaternion.h>
#include <tf/transform_datatypes.h>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>

class CsvNavigator {
private:
    ros::NodeHandle nh_;
    std::string csv_file_path_;
    std::vector<geometry_msgs::PoseStamped> poses_;
    actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> ac_;

    // Inner class to read CSV
    class CsvReader {
    public:
        static std::vector<geometry_msgs::PoseStamped> read(const std::string& path, const std::string& frame_id = "map") {
            std::ifstream file(path);
            std::string line;
            std::vector<geometry_msgs::PoseStamped> result;
            float BIAS_X = 18.025; // Bias for x coordinate based on the position of the map
            float BIAS_Y = 10.8;   // Bias for y coordinate, based on the position of the map


            if (!file.is_open()) {
                throw std::runtime_error("Cannot open CSV file: " + path);
            }

            while (std::getline(file, line)) {
                std::stringstream ss(line);
                std::string item;
                float x, y, theta;

                if (std::getline(ss, item, ',')) x = std::stof(item);
                if (std::getline(ss, item, ',')) y = std::stof(item);
                if (std::getline(ss, item, ',')) theta = std::stof(item);

                geometry_msgs::PoseStamped pose;
                pose.header.frame_id = frame_id;
                pose.pose.position.x = x  + BIAS_X;
                pose.pose.position.y = y  + BIAS_Y;
                pose.pose.position.z = 0;

                tf::Quaternion q = tf::createQuaternionFromYaw(theta* M_PI / 180.0);
                tf::quaternionTFToMsg(q, pose.pose.orientation);

                result.push_back(pose);
            }

            file.close();
            return result;
        }
    };

public:
    
    CsvNavigator() : ac_("move_base", true) {
        nh_.param<std::string>("csv_file_path", csv_file_path_, "goals.csv");

        try {
            poses_ = CsvReader::read(csv_file_path_);
            ROS_INFO("Loaded %lu goals from CSV", poses_.size());
        } catch (const std::exception& e) {
            ROS_ERROR("Error reading CSV: %s", e.what());
        }

        ROS_INFO("Waiting for move_base action server...");
        ac_.waitForServer();
        ROS_INFO("Connected to move_base.");
    }

    void sendGoals() {
        for (size_t i = 0; i < poses_.size(); ++i) {
            move_base_msgs::MoveBaseGoal goal;
            goal.target_pose = poses_[i];
            goal.target_pose.header.stamp = ros::Time::now();

            ROS_INFO("Sending goal %lu: x=%.2f, y=%.2f, theta=%.2f", 
                     i, 
                     goal.target_pose.pose.position.x, 
                     goal.target_pose.pose.position.y, 
                     tf::getYaw(goal.target_pose.pose.orientation));

            ac_.sendGoal(goal);
            ac_.waitForResult();

            if (ac_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED) {
                ROS_INFO("Goal %lu reached", i);
            } else {
                ROS_WARN("Failed to reach goal %lu", i);
                break; // puoi decidere se fermare o continuare
            }

            ros::Duration(1.0).sleep(); // opzionale: pausa tra i goal
        }
    }
};

int main(int argc, char** argv) {
    ros::init(argc, argv, "csv_move_base_client");
    CsvNavigator navigator;
    navigator.sendGoals();
    return 0;
}